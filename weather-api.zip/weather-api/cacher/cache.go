package cacher

import (
	"fmt"
	"time"

	"github.com/patrickmn/go-cache"
)

var c *cache.Cache

func init() {
	c = cache.New(time.Minute*15, time.Minute*30)
}
func Addcache(a map[string]interface{}, s string) {
	c.Set(s, a, 15*time.Minute)
	fmt.Println("Added Cache")
}

func Readcache(s string) (any, bool) {
	var f bool
	var d any
	if d, f = c.Get(s); f {
		//fmt.Println(d)
		fmt.Println("Cache found")
		return d, true
	} else {
		return nil, false
	}

}
